<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST["name"]);
    $email = htmlspecialchars($_POST["email"]);
    $message = htmlspecialchars($_POST["message"]);

    $to = "your-email@example.com"; // Ersetzen Sie dies durch Ihre E-Mail-Adresse
    $subject = "Neue Nachricht von FourLeads Website";
    $headers = "From: $email";
    $body = "Name: $name\nE-Mail: $email\n\nNachricht:\n$message";

    if (mail($to, $subject, $body, $headers)) {
        echo "Nachricht erfolgreich gesendet!";
    } else {
        echo "Es gab ein Problem beim Senden der Nachricht.";
    }
} else {
    echo "Ungültige Anfrage.";
}
?>